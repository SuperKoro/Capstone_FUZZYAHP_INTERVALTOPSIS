﻿ỨNG DỤNG ĐÁNH GIÁ VÀ LỰA CHỌN NHÀ CUNG CẤP
Supplier Selection Application v1.0.0
=========================================

HƯỚNG DẪN CÀI ĐẶT - CỰC KỲ ĐƠN GIẢN!

BƯỚC 1: GIẢI NÉN
1. Nhấn chuột phải vào file ZIP
2. Chọn "Giải nén..." 
3. Giải nén vào Desktop hoặc Documents

BƯỚC 2: CHẠY ỨNG DỤNG
1. Mở thư mục "SupplierSelection"
2. Double-click "SupplierSelection.exe"
3. XONG!

 NẾU WINDOWS CẢNH BÁO "Windows protected your PC":
1. Click "More info"
2. Click "Run anyway"

KHÔNG cần cài Python hay bất kỳ phần mềm nào!

BẮT ĐẦU:
- Click "New" để tạo dự án
- Nhấn F1 để xem hướng dẫn

PHÍM TẮT:
Ctrl+S: Lưu
Ctrl+N: Dự án mới
F1: Hướng dẫn

HỖ TRỢ: [Thêm email/phone của bạn]
